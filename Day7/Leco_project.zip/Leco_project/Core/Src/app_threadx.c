/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    app_threadx.c
  * @author  MCD Application Team
  * @brief   ThreadX applicative file
  ******************************************************************************
    * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "app_threadx.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include<stdio.h>
#include"string.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
TX_THREAD Body_temp_thread_id;
TX_THREAD Body_movement_thread_id;
TX_THREAD UART_thread_id;

extern UART_HandleTypeDef huart1;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */
void Body_temp_thread(ULONG thread_input);
//void Mutexone_entry(ULONG thread_input);
void Body_movement_thread(ULONG thread_input);
void UART_thread(ULONG thread_input);
void App_Delay(uint32_t Delay);

/* USER CODE END PFP */

/**
  * @brief  Application ThreadX Initialization.
  * @param memory_ptr: memory pointer
  * @retval int
  */
UINT App_ThreadX_Init(VOID *memory_ptr)
{
  UINT ret = TX_SUCCESS;
  TX_BYTE_POOL *byte_pool = (TX_BYTE_POOL*)memory_ptr;

   /* USER CODE BEGIN App_ThreadX_MEM_POOL */
  (void)byte_pool;

  CHAR *pointer1,*pointer2, *pointer3;

  /* USER CODE END App_ThreadX_MEM_POOL */

  /* USER CODE BEGIN App_ThreadX_Init */


  /* Allocate the stack for ThreadOne.  */


  if (tx_byte_allocate(byte_pool, (VOID **) &pointer1,
                         APP_STACK_SIZE, TX_NO_WAIT) != TX_SUCCESS)
    {
      ret = TX_POOL_ERROR;
    }

    /* Create Body temperature thread*/
    if (tx_thread_create(&Body_temp_thread_id, "Body temperature thread", Body_temp_thread, 0,
                         pointer1, APP_STACK_SIZE,
                         THREAD_ONE_PRIO, THREAD_ONE_PREEMPTION_THRESHOLD,
						 TX_16_ULONG , TX_AUTO_START) != TX_SUCCESS)
    {
      ret = TX_THREAD_ERROR;
    }

    if (tx_byte_allocate(byte_pool, (VOID **) &pointer2,
                             APP_STACK_SIZE, TX_NO_WAIT) != TX_SUCCESS)
        {
          ret = TX_POOL_ERROR;
        }

        /* Create Body movement thread */
        if (tx_thread_create(&Body_temp_thread_id, "Body movement thread", Body_movement_thread, 0,
                             pointer2, APP_STACK_SIZE,
							 THREAD_TWO_PRIO, THREAD_TWO_PREEMPTION_THRESHOLD,
							 TX_16_ULONG , TX_AUTO_START) != TX_SUCCESS)
        {
          ret = TX_THREAD_ERROR;
        }

        /* Create UART print thread */
        if (tx_byte_allocate(byte_pool, (VOID **) &pointer3,
                                    APP_STACK_SIZE, TX_NO_WAIT) != TX_SUCCESS)
               {
                 ret = TX_POOL_ERROR;
               }

               /* Create Thread three.  */
               if (tx_thread_create(&Body_temp_thread_id, "UART print thread", UART_thread, 0,
                                    pointer3, APP_STACK_SIZE,
       							 THREAD_THREE_PRIO, THREAD_THREE_PREEMPTION_THRESHOLD,
       							 TX_16_ULONG , TX_AUTO_START) != TX_SUCCESS)
               {
                 ret = TX_THREAD_ERROR;
               }
  /* USER CODE END App_ThreadX_Init */

  return ret;
}

  /**
  * @brief  MX_ThreadX_Init
  * @param  None
  * @retval None
  */
void MX_ThreadX_Init(void)
{
  /* USER CODE BEGIN  Before_Kernel_Start */

  /* USER CODE END  Before_Kernel_Start */

  tx_kernel_enter();

  /* USER CODE BEGIN  Kernel_Start_Error */

  /* USER CODE END  Kernel_Start_Error */
}

/* USER CODE BEGIN 1 */

/**
  * @brief  Function implementing the ThreadOne thread.
  * @param  thread_input: Not used
  * @retval None
  */

void Body_temp_thread(ULONG thread_input)
{

}


void Body_movement_thread(ULONG thread_input)
{

}

void UART_thread(ULONG thread_input)
{

}

/**
  * @brief  Application Delay function.
  * @param  Delay : number of ticks to wait
  * @retval None
  */
void App_Delay(uint32_t Delay)
{
  UINT initial_time = tx_time_get();
  while ((tx_time_get() - initial_time) < Delay);
}
/* USER CODE END 1 */
